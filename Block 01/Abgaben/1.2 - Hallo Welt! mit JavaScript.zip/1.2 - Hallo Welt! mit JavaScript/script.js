document.addEventListener('DOMContentLoaded', () => {
  const button = document.getElementById('myButton');
  button.onclick = () => {
    alert('Hallo Welt');
  };
});
