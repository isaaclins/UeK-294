# Memory
## Sources
https://de.wikipedia.org/wiki/Liste_der_Wappen_und_Fahnen_der_Schweizer_Kantone